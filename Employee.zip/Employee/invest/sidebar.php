<li class="nav-header">
                    
                    <div class="logo-element">
                        IN+
                    </div>
                </li>
                <li class="active">
                <a href="../index.php"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a></li>
				<li>
                    <a href="#"><i class="fa fa-user"></i> <span class="nav-label">Account</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="../profile.php">View Profile</a></li>
					  <li><a href="../edit-profile.php">Edit Profile</a></li>
  					<li><a href="../security/2FA.php">Security</a></li>
					  <li><a href="../security/verify.php">Verify Account</a></li>
                    </ul>
                </li>
			
				
			 <li>
                    <a href="../changepassword.php"><i class="fa fa-key"></i> <span class="nav-label">Change Password</span></a>
                </li>
					
				 <li>
                    <a href="../packages.php"><i class="fa fa-gift"></i> <span class="nav-label">Investment Packages</span></a>
                </li>
				 <li>
                    <a href="#"><i class="fa fa-dollar"></i> <span class="nav-label">Deposit</span></a>
                </li>
							 <li>
                    <a href="../withdraw/withdraw.php"><i class="fa fa-bank"></i> <span class="nav-label">Withdraw</span></a>
                </li>
				 <li>
                    <a href="../transaction.php"><i class="fa fa-database"></i> <span class="nav-label">Transaction Log</span></a>
                </li>
				<li>
                    <a href="../send-complaint.php"><i class="fa fa-envelope-o"></i> <span class="nav-label">Complain/Ticket</span></a>
                </li>
              <li>
                    <a href="#"><i class="fa fa-gear"></i> <span class="nav-label">Settings</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse">
						 <li><a href="../withdraw/edit-bank.php">Edit Bank Account</a></li>
 				 
                    </ul>
                </li>