<style type="text/css">
<!--
.style3 {color: #FFFFFF}
.style4 {font-weight: bold}
.style5 {font-size: 14px}
-->
</style>
 <div class="footer style3">
<div class="style4"> <p align="center" class="style5"> Copyright @ [<?php echo date("Y")?>] | An Employee Management System |eMobillis Bootcamp Project | All Rights Reserved </p>
</div>
</div>
