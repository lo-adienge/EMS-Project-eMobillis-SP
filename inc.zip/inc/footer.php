<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
.style2 {
	font-size: 14px;
	color: #000000;
}
-->
</style>
 <div class="footer">
          <div class="style1"> <p align="center" class="style2"> Copyright @ [<?php echo date("Y")?>] | An Employee Management System |eMobillis Bootcamp Project | All Rights Reserved </p>
</div>
</div>
